import json, os

def handler(event, context):
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Hello from Lambda",
            "env": os.environ.get("ENV", "unknown")
        })
    }
